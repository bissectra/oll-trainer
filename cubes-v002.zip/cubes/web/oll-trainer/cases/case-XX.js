var case_cube_data = JSON.parse(localStorage.getItem('our_data'));
var orient = JSON.parse(localStorage.getItem('orientation'));

var found = false;
var rotations = 0;
var case_number;
while (!found && rotations < 4)
{
  for (var i = 0; i < 57; ++i)
  {
    var equal = true;
    for (var j = 0; j < 8; ++j)
    {
      if (case_cube_data[j] != orient[i][j])
      {
        equal = false;
        break;
      }
    }
    if (equal)
    {
      found = true;
      case_number = i;
      break;
    }
  }
  if (!found)
  {
    y_rot(case_cube_data);
    rotations++;
  }
}
update(case_cube_data);

var bdy = document.body;
var case_info = document.createElement("span");
case_info.id = "case-info";
document.title = "Case " + (1 + case_number);
bdy.appendChild(case_info);

var ttl = document.createElement("p");
ttl.id = "title";
var ttl_txt = document.createTextNode("Case " + (case_number + 1));
ttl.appendChild(ttl_txt);
case_info.appendChild(ttl);

var br = document.createElement("br");
case_info.appendChild(br);
var alg_el = document.createElement("p");
alg_el.classList.add("alg");
var alg_txt = document.createTextNode(JSON.parse(
              localStorage.getItem('algs'))[case_number]);
alg_el.appendChild(alg_txt);
case_info.appendChild(alg_el);

if (JSON.parse(localStorage.getItem('algs_'))[case_number] != null)
{
  br = document.createElement("br");
  case_info.appendChild(br);
  var alg2_el = document.createElement("p");
  alg2_el.classList.add("alg2");
  var alg2_txt = document.createTextNode(JSON.parse(
                localStorage.getItem('algs_'))[case_number]);
  alg2_el.appendChild(alg2_txt);
  case_info.appendChild(alg2_el);
}

br = document.createElement("br");
case_info.appendChild(br);
var div = document.createElement("div");
div.id = "comment-div";
var comment_el = document.createElement("p");
comment_el.classList.add("comment");
var comment_txt = document.createTextNode(JSON.parse(
              localStorage.getItem('comments'))[case_number]);
comment_el.appendChild(comment_txt);
div.appendChild(comment_el);
case_info.appendChild(div);

function y_rot (or_array)
{
  var corner_temp = or_array[0];
  var   edge_temp = or_array[1];
  or_array[0] = or_array[6];
  or_array[6] = or_array[4];
  or_array[4] = or_array[2];
  or_array[2] = corner_temp;
  or_array[1] = or_array[7];
  or_array[7] = or_array[5];
  or_array[5] = or_array[3];
  or_array[3] =   edge_temp;
}
